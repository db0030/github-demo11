(function () 
{
	
  'use strict';

  angular.module("myApp")
	.config(config);
  

  config.$inject = ['$stateProvider','$urlRouterProvider'];
	   
  function config($stateProvider, $urlRouterProvider)
  {

 
    	 $urlRouterProvider
       .otherwise("/login")

        $stateProvider
        .state('login',
         {
            url: '/login',
            templateUrl: "views/login.html",
            controller: 'logController',
        })
          
        .state('/signup',
         {
            url: '/signup',
            templateUrl: "views/signup.html",
            controller:  'signController',
        })

        .state('/addressBook', 
        {
            
            url: '/addressBook',
            templateUrl: "views/addressBook.html",
            controller:  'addressBookCtrl',
        })
     
        .state('/createadressBook', 
        {
            
             url: '/createadressBook',
             templateUrl: "views/createadressBook.html",
             controller:  'addressBookCtrl',
         })

          .state('/contacts', {
            
             url: '/contacts/:id',
             templateUrl: "views/contacts.html",
             controller:  'createContactCtrl',
         })
  }
})();

