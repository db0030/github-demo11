	 angular.module("myApp")
	.controller('addressBookCtrl',addressBookCtrl)
	//.controller('createAdressBookCtrl',createAdressBookCtrl)
	.controller('createContactCtrl',createContactCtrl);
	addressBookCtrl.$inject = ['$scope', '$location', '$http', '$rootScope'];
	
	function addressBookCtrl($scope,$location, $http, $rootScope) 
	{
		$scope.adressBook = {};
		$scope.adressBook1 = {};
		$scope.adressBook2 = {};


		$scope.getAdressBook = function() 
		{
			$http.get('api/AddressBooks')
			.then (function (res)
			{ 
				// console.log(res);
				 $scope.adressBook = res.data; 
			},
			function(err)
			{	
            	console.log(err);
 			});
 		}
		
		$scope.getAdressBook();
		$scope.getbook = function()
		{
			
			console.log($scope.adressBook1);
			$http.post('http://localhost:4516/api/AddressBooks' ,$scope.adressBook1)
 			.then (function (res)
 			{
				$location.path('/addressBook');	
			}, 
			function(err)
			{
                 console.log(err);
 					
 			});
 		}

 		
 		$scope.deleteAdressBook = function(id)
 		{
 			$http.delete("http://localhost:4516/api/AddressBooks/" + id)
			.then (function (res)
 			{
 				console.log(JSON.stringify(res));
 				
 			},
			function(res)
			{
                 console.log(res);
 					//log error
 			});

 			$scope.getAdressBook(); 
 		}

 		$scope.setAdressBook = function(data)
 		{	
 			//console.log(data);
 			$scope.adressBook2 = data;
 			console.log($scope.adressBook2);
 		}

 		$scope.saveAdressBook = function()
 		{
 			$http.put("api/AddressBooks",$scope.adressBook2) 		
 			.then (function (res)
 			{
 				console.log(JSON.stringify(res));
 				$scope.getAdressBook();
 				//$location.path('/addressBook');
					
			}, 
			function(res)
			{
                 	console.log(res);
 					//log error
 			});
 		}
 
	};


	
	createContactCtrl.$inject = ['$scope','$location','$http', '$rootScope','$stateParams'];
	function createContactCtrl($scope, $location, $http, $rootScope, $stateParams)
	{
 					
 			$scope.contactBook = {};   // created json object 
  			$scope.contactBook.addressBookId = $stateParams.id; // assigning addressBookId to json
  			$scope.contactBook.createdById = $rootScope.user;  // login time value of user(createdBYId)  
 			var currentId = $stateParams.id;
	  		
	  			$scope.adData = {};
 
			/* get contact code */
  			$scope.getContact = function()
  			 {
    			$http.get("api/AddressBooks/"+ currentId + "/contacts")
      			.then (function (res)
      			{
       				 console.log(res);
        			 $scope.adData = res.data;
        			
        		},
        		function(err)
        		{
          			console.log(err);
          			
        		});
  			}

  			$scope.getContact();  

  			$scope.addContact = function()
  			{	
				console.log($scope.contactBook);
			 	$http.post("api/AddressBooks/" + currentId + "/contacts", $scope.contactBook)
	    		.then (function (res)
	    		{
	    				
	    				console.log(JSON.stringify(res));          
	     				alert("Contact added successfully!!"); 
	      				$scope.getContact(); 
	      				
	   			},
	   			function(err)
	   			{
	      			 console.log(err);
	  			});
  			}


        	$scope.deleteContact = function(id)
			{
				console.log(id);
    			$http.delete("api/Contacts/" + id)
      			.then (function (res)
      			{
       				console.log(JSON.stringify(res));
        			$scope.getContact();
      			},
      			function(res)
      			{
          			//log error
      			});
  			}

			$scope.setContact = function(data)
			{
				console.log(data);
				$scope.contactBook = data;
  				
			};


		$scope.saveContact = function()
			{
  				
    			$http.put("api/Contacts" ,$scope.contactBook)
      			.then (function (res)
      			{
        			console.log(JSON.stringify(res));
       				$scope.getContact();
      			},
      			function(res)
      			{
 			         //log error
      			});
  			}
};


		
		




	
	
